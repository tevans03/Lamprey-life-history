
# This is the user-interface definition of a Shiny web application.
# You can find out more about building applications with Shiny here:
#
# http://shiny.rstudio.com
#

library(shiny)
library(matrixStats)
library(plyr)


ui <- pageWithSidebar(
  # Application title
  headerPanel("Lamprey Life History Model"),
  # Sidebar with inputs
  sidebarPanel(

               tabsetPanel(
                 tabPanel("Overall Model",
                          numericInput ("reps", "Model Iterations", value=1000, min=1, max=100000),
                          actionButton("submit", "Run the model", style="color: black; background-color: coral"), br(), hr(),
                          
                          fileInput('file1', 'Choose a Strategy File', accept='.txt'), 
                          p("Note: None needed if strategies displayed are acceptable"), hr(),
                          
                          selectInput("par.color", "Parasitic Strategy Color", c("Black"="black", "Light Grey"= "grey60", "Dark Grey" = "grey30", "Red" = "red", "Blue" = "blue", "Green"= "green", "Orange"= "orange")),
                          selectInput("non.par.color", "Non-Parasitic Strategy Color", c("Light Grey"= "grey60", "Dark Grey" = "grey30", "Black"="black", "Red" = "red", "Blue" = "blue", "Green"= "green", "Orange"= "orange"))),
                 tabPanel("Ammocoete",
                          div(style="width: 200px", 
                              numericInput ("Wi", "Initial Weight (g)", value=0.12, min=0.01, max=4)),
                          hr(),
                          p(strong("von Bertalanffy parameters")),
                          div(style="display: inline-block;horizontal-align:top; width: 150px;",
                            numericInput ("b", "Length-weight exponent (b)", value=2.611, min=2, max=4)),
                          div(style="display: inline-block;horizontal-align:top; width: 150px;",  
                            numericInput ("Winf", "W-infinity", value=40, min=0.1, max=100)),
                            br(),
                          div(style="display: inline-block;horizontal-align:top; width: 100px;",
                            numericInput ("mean.K", "Mean K (1/yr)", value=0.20, min=0, max=4)),
                          div(style="display: inline-block;horizontal-align:top; width: 100px;",
                              numericInput ("sd.K", "SD K (1/yr)", value=0.05, min=0, max=4)),
                          div(style="display: inline-block;horizontal-align:top; width: 100px;",
                              numericInput ("max.K", "Max K (1/yr)", value=0.5, min=0, max=8)),
                          hr(),
                          
                          p("Note: The 'Rate of Change of K' below is only used if density dependence is set to 'Yes'."),
                          div(style="display: inline-block; width: 200px",
                              radioButtons ("dense.dep", "Density Dependence?", c("Yes" = 1, "No" = 0), selected=0, inline=T)), 
                          div(style="display: inline-block; width: 200px",
                              numericInput ("rate.K", "Rate of Change of K (1/yr^2)", value=0.05, min=0, max=4)),
                          radioButtons ("color.grow", "Color in ammocoete growth parameters?", c("Yes" = 1, "No" = 0), selected=0, inline=T),
                          hr(),
                          
                              sliderInput ("amms.mean", "Mean survival", min=0.01, max=1, value=0.67),
                              sliderInput ("amms.sd", "SD survival", min=0.00, max=1, value=0.14)
                         ),
                 tabPanel("Juvenile",                
                          numericInput ("juv.growth", "Annual growth rate (g/yr)", value=7.78, min=10^5, max=10^5),
                          numericInput ("juv.growth.sd", "SD daily growth rate (g/yr)", value=1.95, min=0, max=10^5),
                          numericInput ("c", "c (g/(yr*yr))", value=0, min=-10^5, max=10^5),
                          br(),

                          sliderInput ("juvs.mean", "Mean survival", min=0.01, max=1, value=0.08),
                          sliderInput ("juvs.sd", "SD survival", min=0.00, max=1, value=0.02),
                          numericInput ("W.LJ", "Cutoff length", min=0.0, max=100, value=0.5)
                         ),
                 tabPanel("Metamorphic", 
                          numericInput ("trans.grow" , "Percent growth (%)", value=0, min=-100, max=100),
                          sliderInput ("trans.mean", "Mean survival", min=0.01, max=1, value=0.67),
                          sliderInput ("trans.sd", "SD survival", min=0.01, max=1, value=0.14)
                         ),
                 tabPanel("Adult", 
                          numericInput ("adult.grow" , "Percent growth (%)", value=0, min=-100, max=100),
                          numericInput ("epg", "Mean relative fecundity (eggs/g)", value=400, min=1, max=1000),
                          numericInput ("epg.sd", "SD relative fecundity (eggs/g)", value=0, min=0, max=1000),
                          sliderInput  ("adusmax", "Survival", min=0.01, max=1, value=0.5),
                          numericInput ("W.LD", "Cutoff length", min=0.0, max=100, value=0.5)
                         )
               )),
  # Show a plot of the generated distribution
  mainPanel(
    tabsetPanel(
      tabPanel("Strategies",
               helpText ("Where: 1 is the ammocoete stage, 2 is the metamorphic/transformer stage, 3 is the juvenile stage, and 4 is the adult stage"),
               tableOutput("content")),
      tabPanel("Ammocoete Growth Parameters",
               plotOutput("plotkdist"),
               helpText ("Growth parameter K either overall ('Average K'), or for the age during which it would be applied (e.g., 'Age-1'). Dotted lines show the means used to generate the distributions."),br(),
               plotOutput("plotvonbert"),
               helpText ("Parameters within the model are used to fit von Bertalanffy curves. The grey area is th 95% confidence interval for the density independent von Bertalanffy curve.")),
      tabPanel("Juvenile Growth Parameters",
               plotOutput("linearjuvdailygrowth"),
               helpText ("The points mark the mean of growth per year, the error bars are the 95% confidence intervals based on the standard deviations selected, and the light grey dashed line marks zero growth per day. The mean growth per year is printed next to each point.")),
      tabPanel("Survival Distributions", 
               plotOutput("survivals")),
      tabPanel("Model Output", 
               plotOutput("plot1"),br(),
               plotOutput("plot2"),br(), br(), p(strong("Summary of Strategies Adopted (Best at top)") ),
               tableOutput("summary"),
               helpText ("Where: 1 is the ammocoete stage, 2 is the metamorphic/transformer stage, 3 is the juvenile stage, and 4 is the adult stage"))
    )
  )
)
