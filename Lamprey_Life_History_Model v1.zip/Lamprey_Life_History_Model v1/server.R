
# This is the server logic for a Shiny web application.
# You can find out more about building applications with Shiny here:
#
# http://shiny.rstudio.com
#

library(shiny)

server <- function(input, output, session){
  
  
  output$content <- renderTable({
    inFile <- input$file1
    
    if (is.null(inFile)){
      read.table("data/Strategies_Final.txt", header = T, sep="\t")
    } else {
      read.table(inFile$datapath, header = T, sep="\t")
    }
  })
  
  
  strats <- reactive ({
    inFile <- input$file1
    if (is.null(inFile)){
      read.table("data/Strategies_Final.txt", header = T, sep="\t")
    } else {
      read.table(inFile$datapath, header = T, sep="\t")
    }
  })
  
  ######## Parameter Plots ##########
  ## Ammocoete plots ##
  # Top plot, with K distributions
  output$plotkdist <- renderPlot ({

    temp.K <- rnorm(1000,input$mean.K, input$sd.K)
    temp.K <- temp.K [ temp.K <= input$max.K & temp.K > 0]
    
    hist.store<-hist(temp.K, breaks=seq(0, input$max.K, l=100))
    xaxis <- max(150, signif(max(hist.store$counts)*1.1,1))
    yaxis <- max(150, signif(max(hist.store$counts)*2))
    
    color <- c( rgb(1,0,0,0.5), rgb(1,0.5,0,0.5), rgb(176/255,196/255,222/255), rgb(0,1,0,0.5),rgb(0,1,1,0.5),
                rgb(0,0.5,1,0.5), rgb(0,0,1,0.5), rgb(0.5,0.25,1,0.5), rgb(1,0.25,1,0.5), rgb(1,0,0.5,0.5),
                rgb(210/255,105/255,30/255,0.5), rgb(75/255,0,130/255,0.5), rgb(0,0.5,0,0.5), rgb(255/255,215/255,0,0.5),
                rgb(128/255,0/255,0/255,0.5), rgb(250/255,128/255,114/255,0.5), rgb(255/255,250/255,205/255,0.5)) #this vector is used to generate colors, the user is not allowed to modify this unless they come "under the hood" so to speak

   
    par(mar=c(5,5,5,0.5))
    hist(temp.K, breaks=seq(0, input$max.K, l=100),
         col=ifelse(input$color.grow==0, rgb(0.3,0.3,0.3,0.5), rgb(25/255,25/255,112/255)), border="white", 
         xlim=c(0, input$max.K), ylim=c(0,yaxis), 
         xlab="K (1/year)", ylab="Counts", 
         main="Ammocoete von Bertalanffy growth parameter",
         cex.main=1.6, cex.axis=1.4, cex.lab=1.6)
    #This will update on the fly BEFORE the model is run, so the run model button still has to be clicked
    segments(x0=mean(temp.K, na.rm=T), y0=0, x1=mean(temp.K, na.rm=T), y1=signif(max(hist.store$counts)*1.1,1), lty=2, lwd=0.9)
    text("Average K",x=mean(temp.K, na.rm=T), y=max(signif(max(hist.store$counts)*1.1,1)*1.3,30), srt=90, cex=1.2)
    
    #Note these are simulations of the model, the model picks its own K values once it runs. However, these simulations are probably all very similar since it calls for 1000 random values.
    if(input$dense.dep==1){
     if(input$color.grow==0){ 
      storage.K <- matrix(ncol=0, nrow=1000)
      
      for (n in 1: (ncol(strats())-1) ) {
        if (input$rate.K*n < input$mean.K) {
        temp.dens.K <- rnorm(1000,input$rate.K*n, input$sd.K)
        temp.dens.K <- temp.dens.K [ temp.dens.K <= input$max.K & temp.dens.K > 0]
        temp.dens.K <- c(temp.dens.K, rep(NA, 1000-length(temp.dens.K)) )
        
        storage.K <- cbind(storage.K,temp.dens.K)
        
        hist(storage.K[,n], breaks=seq(0, input$max.K, l=100), add=T,
        col=rgb(0.6,0.6,0.6,0.5), border=rgb(0.6,0.6,0.6,0.5))

        }
      }
      
      for (p in 1:ncol(storage.K)) {
        
        segments(x0=mean(storage.K[,p], na.rm=T), y0=0, x1=mean(storage.K[,p], na.rm=T), y1=signif(max(hist.store$counts)*1.1,1), lty=3, lwd=0.9)
        text(paste("Age-",p),x=mean(storage.K[,p], na.rm=T), y=max(signif(max(hist.store$counts)*1.2,1)*1.15,20), srt=90 )
        
       }
     } else if (input$color.grow==1) {
       storage.K <- matrix(ncol=0, nrow=1000)
       
       for (n in 1: (ncol(strats())-1) ) {
         if (input$rate.K*n < input$mean.K) {
           temp.dens.K <- rnorm(1000,input$rate.K*n, input$sd.K)
           temp.dens.K <- temp.dens.K [ temp.dens.K <= input$max.K & temp.dens.K > 0]
           temp.dens.K <- c(temp.dens.K, rep(NA, 1000-length(temp.dens.K)) )
           
           storage.K <- cbind(storage.K,temp.dens.K)
           
           hist(storage.K[,n], breaks=seq(0, input$max.K, l=100), add=T,
                col=color[n], border=rgb(0.6,0.6,0.6,0.5))
           
         }
       }
       
       for (p in 1:ncol(storage.K)) {
         
         segments(x0=mean(storage.K[,p], na.rm=T), y0=0, x1=mean(storage.K[,p], na.rm=T), y1=signif(max(hist.store$counts)*1.1,1), lty=3, lwd=0.9)
         text(paste("Age-",p),x=mean(storage.K[,p], na.rm=T), y=max(signif(max(hist.store$counts)*1.2,1)*1.15,20), srt=90 )
         
       }
     }
    }
       }) #end of plot command
  
  output$plotvonbert <- renderPlot ({
    
    vblf_w <- function(Winf, K, t, b) {
      Winf * ( 1 - exp(-K*(t+1)) )^b
    }
    
    color <- c( rgb(1,0,0), rgb(1,0.5,0), rgb(176/255,196/255,222/255), rgb(0,1,0),rgb(0,1,1),
                rgb(0,0.5,1), rgb(0,0,1), rgb(0.5,0.25,1), rgb(1,0.25,1), rgb(1,0,0.5),
                rgb(210/255,105/255,30/255), rgb(75/255,0,130/255), rgb(0,0.5,0), rgb(255/255,215/255,0),
                rgb(128/255,0/255,0/255), rgb(250/255,128/255,114/255), rgb(255/255,250/255,205/255))
    
    temp.K <- rnorm(1000,input$mean.K, input$sd.K)
    temp.K <- temp.K [ temp.K <= input$max.K & temp.K > 0]
    
    #this is a dummy point, there are many ways to make a blank plot but this is easy because we will never have negative ages
    plot(x=-99, y=-99,  
         ylim=c(0, input$Winf), xlim=c( 0,ncol(strats()) ),
         xlab="Ammocoete age (years)", ylab="Total weight (g)", main="von Bertalanffy curves",
         cex.main=1.6, cex.axis=1.4, cex.lab=1.6)
    
    polygon( x=c(0:ncol(strats()), ncol(strats()):0) ,
             y=c(vblf_w (Winf=input$Winf, K=mean(temp.K, na.rm=T)-1.96*input$sd.K, t=c(0:ncol(strats())), b=input$b),
                 vblf_w (Winf=input$Winf, K=mean(temp.K, na.rm=T)+1.96*input$sd.K, t=c(ncol(strats()):0), b=input$b)),
             col=ifelse(input$color.grow==0, rgb(0.8,0.8,0.8,0.5), rgb(25/255,25/255,112/255, 0.1)), border=NA)
    
    curve(vblf_w (Winf=input$Winf, K=mean(temp.K, na.rm=T), t=x, b=input$b), from=0, to=ncol(strats()),
          lwd=2, add=T, col=ifelse(input$color.grow==0, "black", rgb(25/255,25/255,112/255)) )
    
    abline(h=input$Winf, lty=3, col="grey50")
    text(expression("W"[infinity]), x=1/15*ncol(strats()), y=input$Winf*0.95, cex=1.6, col="grey50" )
    
    if(input$dense.dep==1){
      storage.K <- matrix(ncol=0, nrow=1000)
      
      for (n in 1: (ncol(strats())-1) ) {
        if (input$rate.K*n < input$mean.K) {
          temp.dens.K <- rnorm(1000,input$rate.K*n, input$sd.K)
          temp.dens.K <- temp.dens.K [ temp.dens.K <= input$max.K & temp.dens.K > 0]
          temp.dens.K <- c(temp.dens.K, rep(NA, 1000-length(temp.dens.K)) )
          
          storage.K <- cbind(storage.K,temp.dens.K)
        }
      }
    
      for ( p in 1:ncol(storage.K) ) {
          curve(vblf_w( Winf=input$Winf, K=mean(storage.K[,p], na.rm=T), t=x, b=input$b ), from=0, to=ncol( strats() ),
          lwd=2, lty=2, add=T, col=ifelse(input$color.grow==0, "black", color[p]))
      }
    }
  })
  
  ## Juvenile plot ##
  # Top plot, with daily growth rates distributions
  
  output$linearjuvdailygrowth <- renderPlot ({
    
    max.juv.yr <- max(apply(strats()[,1:ncol(strats())], MARGIN = 1, FUN = function(x) length(x[!is.na(x) & x==3]) )) #count the number of juvenile years as a maximum and create a vector
    temp.x <- seq(1, max.juv.yr, 1) 
    temp.c <- input$c*seq(0,max.juv.yr-1,1 )  #since we don't want c applied in the first year we generate a vector from 0 to the max number of juvenile strats, by year (1 at the end)
    temp.y <- input$juv.growth+temp.c
    
    par(mar=c(5,5,4,0.5), cex.axis=1.5)
    plot(x=temp.x, y=temp.y, type="p", xaxt="n",
         xlim=c(1, 3), ylim=c(min (0, 1.1*(input$juv.growth-input$juv.growth.sd*1.96 ), 1.1*(input$juv.growth+input$c*max.juv.yr-input$juv.growth.sd*1.96 )), 1.1*(max(temp.y)+input$juv.growth.sd*1.96) ),
         pch=21, cex=2.5, col="black", 
         xlab="", ylab="Growth rate (g/yr)", 
         main="Juvenile daily growth rate", cex.lab=1.6, cex.main=1.6, cex.axis=1.4)
    axis(1, at=c(1,2,3), labels=(1:3))
    
    text(x=c(1.16,2.16,2.82), y=temp.y, paste(temp.y, "g/yr") )
    abline(h=0, lty=3, col="grey50")  #zero growth line
    mtext(side=1, line=3, "Years feeding parasitically", cex=1.6)
    
    if(input$juv.growth.sd>0) {
        arrows(temp.x, input$juv.growth+temp.c-input$juv.growth.sd*1.96, temp.x, input$juv.growth+temp.c+input$juv.growth.sd*1.96, angle=90, length=0.15, code=3)
        }  #This if statement is necessary to prevent throwing errors when SD falls to zero
    
    points(x=temp.x, y=temp.y, pch=21, cex=2.5,
           col="black", bg="white", lwd=2)
    
  })
  
#### Survival plot ####
  
  output$survivals <- renderPlot ({
    
    amms.dist  <- rnorm(1000, input$amms.mean, input$amms.sd)
    amms.dist  <- amms.dist [ amms.dist <= 1 & amms.dist >= 0]
    ammshist   <- hist(x=amms.dist, breaks=seq(0,1, l=100), plot=F)
    
    #juvenile survival
    juvs.dist <- rnorm(1000, input$juvs.mean, input$juvs.sd)
    juvs.dist <- juvs.dist [ juvs.dist <= 1 & juvs.dist >= 0 ]
    juvshist <- hist(x=juvs.dist, breaks=seq(0,1, l=100), plot=F)
    
    #transformer survival
    trans.dist  <- rnorm(1000, input$trans.mean, input$trans.sd)
    trans.dist  <- trans.dist [ trans.dist <= 1 & trans.dist >= 0]
    transhist <- hist(x=trans.dist, breaks=seq(0,1, l=100), plot=F)
    
    ylimmaxhists <- max(150, max(signif(max(ammshist$counts)*1.1,1), signif(max(transhist$counts)*1.1,1), signif(max(juvshist$counts)*1.1,1)))
    breaks <- ifelse(ylimmaxhists<=250, 50, ifelse(ylimmaxhists>250 & ylimmaxhists<=500, 100, 200))
    
    
    par(mfrow=c(2,2), mar=c(2, 2, 0, 0), oma=c(4,4,2,2), mgp=c(2,1,0), xaxs="i", yaxs="i",
        cex.main=1.6, cex.axis=1.4, cex.lab=1.6)
    
    hist(x=amms.dist , breaks=seq(0,1, l=100), xaxt="n", yaxt="n",
         xlim=c(0,1), ylim=c(0,ylimmaxhists), xlab="", ylab="Counts", main="",
         col=rgb(0.5,0.5,0.5,0.5), border=rgb(0.5,0.5, 0.5, 0.5) )
    text(x=0.5, y=ylimmaxhists*0.9, "Ammocoetes", cex=1.7)
    axis(1, at=c(0,0.2,0.4,0.6,0.8,1.0), labels=F)
    axis(2, at=seq(0,ylimmaxhists,breaks), labels=seq(0, ylimmaxhists, breaks), las=1 )
    mtext(side=2, "Count", line=4, cex=1.6)
    box()
    
    hist(x=juvs.dist, breaks=seq(0,1, l=100), xaxt="n", yaxt="n",
         xlim=c(0,1), ylim=c(0,ylimmaxhists), xlab="", ylab="",main="",
         col=rgb(0.5,0.5,0.5,0.5), border=rgb(0.5,0.5, 0.5, 0.5) )
    text(x=0.5, y=ylimmaxhists*0.9, "Juveniles", cex=1.7)
    axis(1, at=c(0,0.2,0.4,0.6,0.8,1.0), labels=F)
    axis(2, at=seq(0,ylimmaxhists,breaks), labels=F)
    box()
    
    hist(x=trans.dist, breaks=seq(0,1, l=100), yaxt="n", las=2,
         xlim=c(0,1), ylim=c(0,ylimmaxhists), xlab="", ylab="Counts",main="",
         col=rgb(0.5,0.5,0.5,0.5), border=rgb(0.5,0.5, 0.5, 0.5) )
    text(x=0.5, y=ylimmaxhists*0.9, "Metamorphic", cex=1.7)
    axis(2, at=seq(0,ylimmaxhists,breaks), labels=seq(0, ylimmaxhists, breaks), las=1)
    mtext(side=1, "Annual survival rates", line=4, cex=1.6)
    mtext(side=2, "Count", line=4, cex=1.6)
    box()
    
    hist(x=rep(input$adusmax, 1000), breaks=seq(0,1, l=100), yaxt="n",
         xlim=c(0,1), ylim=c(0,ylimmaxhists), xlab="", ylab="",main="",
         col=rgb(0.5,0.5,0.5,0.5), border=rgb(0.5,0.5, 0.5, 0.5), las=2 )
    text(x=0.5, y=ylimmaxhists*0.9, "Adults", cex=1.7)
    axis(2, at=seq(0,ylimmaxhists,breaks), labels=F)
    mtext(side=1, "Annual survival rates", line=4, cex=1.6)
    box()
  })
  
######## Plot from model outputs Production Information ######## 
  output$plot1 <- renderPlot ({

    input$submit
    if(input$submit==0)
      return()
    else
      isolate({
        
        #von Bert growth equation again, just to make it easier to find
        vblf_w <- function(Winf, K, t, b) {
          Winf * ( 1 - exp(-K*(t+1)) )^b
        }
        
        #reverse von Bert to get a relative age used to calculate weight gain
        rev_vblf_w <- function (Wt, Winf, K, b) {
          log( 1-(Wt/Winf)^(1/b) )/-K
        }
        
        #ammocoete von Bert growth
        amm.K <- rnorm(1000, input$mean.K, input$sd.K)
        amm.K <- amm.K [ amm.K <= input$max.K & amm.K > 0]
        
        #juvenile growth
        juvg.dist   <- rnorm (1000, input$juv.growth, input$juv.growth.sd)
        
        #ammocoete survival, same as others below, but create a pool, remove impossible values, add back in maximum or minimum values to replenish vector
        amms.dist <- rnorm(1000, input$amms.mean, input$amms.sd)
        amms.dist <- amms.dist [ amms.dist <= 1 & amms.dist >= 0]
        
        #juvenile survival
        juvs.dist <- rnorm(1000, input$juvs.mean, input$juvs.sd)
        juvs.dist <- juvs.dist [ juvs.dist <= 1 & juvs.dist >= 0 ]
      
        #transformer survival
        trans.dist  <- rnorm(1000, input$trans.mean, input$trans.sd)
        trans.dist  <- trans.dist [ trans.dist <= 1 & trans.dist >= 0]
        
        #Juvenile survival
        juvsfunc <- function (x, juvsmax, W.LJ){
          min(juvsmax*(x/W.LJ), juvsmax) #juvenile mortality is high if animals are <W.LJ, and increases linearly from 0.5 to 1 gram, then juvenile mortality becomes the set value for all other sizes
        }
        
        #Adult survival
        adufunc <- function (x, adusmax, W.LD){
          min(adusmax*(x/W.LD), adusmax)  #adult mortality increases linearly when less than W.LD
        }
        
        #relative fecundity
        epg.dist    <- round ( rnorm (1000, input$epg, input$epg.sd), 0 )
        
        ################################
        #    Make this a rep model     #
        ################################
        rep <- input$reps # number of reps to have in the model
        rep.dec <- data.frame ( matrix(nrow=rep, ncol=ncol(strats())+3, NA)  )
        
        withProgress (message = "Running Model", value=0, {
          
          for (n in 1:rep){
            
            #################################
            #Build matrix for sizes at times#
            #################################
            size <- matrix (nrow=nrow(strats()), ncol=ncol(strats()), NA) #make a size matrix to store the lengths at time
            size[,1] <- input$Wi #populate the first column with growth after one year

            #################################
            # Growth of animals under strat #
            #################################
            for (t in 2:ncol(strats())) {
              
              samp.amm.K <- sample(amm.K, 1)  #pull out a K value for ammocoete growth
              
              if (input$dense.dep==1 & input$rate.K*(t-1) < input$mean.K) {  #generate K's if you want density dependenc effects for each loop
                dens.K <- rnorm(1000,input$rate.K*(t-1), input$sd.K)
                dens.K <- dens.K [ dens.K <= input$max.K & dens.K > 0]
                }
              
              juv.growth <- sample(juvg.dist, 1)   #Pull out a single juvenile growth rate and use it across all strats at this time
              
              for (i in 1:nrow(strats())) {
                
                if(input$dense.dep==1 & input$rate.K*(t-1) < input$mean.K) {
                size[i,t]<- ifelse(size[i,t-1]==0, 0,
                                    ifelse( strats()[i,t]==1, vblf_w(Winf=input$Winf, K=dens.K, t=rev_vblf_w(Wt=size[i,t-1], Winf=input$Winf, K=dens.K, b=input$b)+1, b=input$b),
                                            ifelse(strats()[i,t]==2, size[i,t-1]*(1+input$trans.grow/100), 
                                                    ifelse(strats()[i,t]==3, max ( size[i,t-1] + (juv.growth + input$c * (sum(strats()[i,1:t]==3, na.rm=T)-1) ), 0), size[i, t-1]*(1+input$adult.grow/100) ) ) ) )
                } else if ( input$dense.dep==0 || input$rate.K*(t-1) >= input$mean.K) {
                  size[i,t]<- ifelse(size[i,t-1]==0, 0,
                                     ifelse( strats()[i,t]==1, vblf_w(Winf=input$Winf, K=samp.amm.K, t=rev_vblf_w(Wt=size[i,t-1], Winf=input$Winf, K=samp.amm.K, b=input$b)+1,b=input$b), 
                                             ifelse(strats()[i,t]==2, size[i,t-1]*(1+input$trans.grow/100), 
                                                     ifelse(strats()[i,t]==3, max ( size[i,t-1] + (juv.growth + input$c * (sum(strats()[i,1:t]==3, na.rm=T)-1) ), 0), size[i, t-1]*(1+input$adult.grow/100) ) ) ) )
                 } else { print("Error, how did you get here?")}
                }
            }
            
            #################
            #Survival matrix#
            #################
            
            surv <- matrix (nrow=nrow(strats()), ncol=ncol(strats()), NA) 
            
            for (t in 1:ncol(strats())) {
              
              amms.samp <- sample (amms.dist,1)          #Pull out a single ammocoete survival rate during each year
              juvsmax   <- sample (juvs.dist, 1)         #same for juvenile
              trans.samp <- sample (trans.dist,1)        #same for transformer
              
              for (i in 1:nrow(strats())) {
                surv[i,t]<- ifelse( strats()[i,t]==1, amms.samp,
                                    ifelse(strats()[i,t]==2, trans.samp, 
                                           ifelse(strats()[i,t]==3, juvsfunc(x=size[i,t-1], juvsmax=juvsmax, W.LJ=input$W.LJ), adufunc(x=size[i,t], adusmax=input$adusmax, W.LD=input$W.LD) ) ) )
              }
            }
            surv[is.na(surv)] <- 1 #This allows easy calculations further on and does not change the outcome, one replaces all NA's as a final step
            
            ############################################
            #Creation of liklihood and benefit matrices#
            ############################################
            benefit <- matrix (nrow=nrow(strats()), ncol=5, NA)
            
            #Calculation of best strategies
            epg.samp <- sample ( epg.dist, 1 ) #First randomly pick a relative fecundity
            
            benefit[,1] <- rowProds(surv)                                                                                 #survival probability       ##17
            benefit[,2] <- apply(size, 1, function(x) { tail(x[!is.na(x)], 1) })                                          #adult final size           ##18
            benefit[,3] <- round(benefit[,2] * epg.samp, 0)                                                               #absolute fecundity         ##19
            benefit[,4] <- benefit[,3] * benefit[,1]                                                                      #mean fecundity per female  ##20
            benefit[,5] <- benefit[,4]/apply(strats(), MARGIN = 1, FUN = function(x) length(x[!is.na(x)]) )   #final benefit, eggs per year ##21
            
            #Output benfit and bind them with their strategy so they can be ranked
            benefit <- cbind(strats(), benefit, c(1:nrow(strats())))              #strats for ref         ##22 
            benefit <- benefit[order(benefit[,ncol(strats())+5], decreasing=T),]  #sort by highest value  ##23
            
            #Storage of results for further use
            rep.dec[n,] <- c( benefit[1,1:ncol(strats())], benefit[1,18:19], benefit[1,22] )  #1-16 are the life stages, 18 is the adult size, 19 is the absolute fecundity, 22 is strategy number
            
            incProgress(1/rep, detail = paste0(round((n/rep)*100,0), "%"))
            
          } #end of model
          
        }) # end of progress bar
        
        rep.dec <-  cbind ( rep.dec, apply( rep.dec[,1:ncol(strats())], MARGIN = 1, FUN = function(x) length(x[!is.na(x)]) ) ) #count the maximum age
        rep.dec <-  data.frame(rep.dec)
        colnames(rep.dec) <- c("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16",  "weight", "eggs", "strategy", "maxage")
        rep.dec["parasitic"] <- NA
        for (i in 1:nrow(rep.dec) ) { 
          rep.dec$parasitic[i] <- ifelse ( (3 %in% rep.dec[ i,1:ncol(strats()) ])==T, "Y", "N") 
        }
        
        options(scipen=8)
        xlimmax <- ifelse(max(rep.dec$weight)<10, 10, ifelse(max(rep.dec$weight)<50, 50, ifelse(max(rep.dec$weight)<100, 100, ifelse(max(rep.dec$weight)<500, 500, ifelse(max(rep.dec$weight)<1000, 1000, round(1.1*rep.dec$weight, -1) )))))
        temp <- hist(rep.dec$weight, breaks=seq(0,xlimmax, 0.5), plot=F)
        ylimmax <- max(round(max(ceiling(temp$counts))*1.2,  -1),10)
        
        ylimseq <- ifelse( ylimmax>1000, 200, ifelse(ylimmax>500, 100, ifelse(ylimmax>200, 50, ifelse(ylimmax>50, 25, ifelse(ylimmax>20, 10, 5) ))))
        
        xlabel <- ifelse(xlimmax==10, 5, ifelse(xlimmax==50, 10, ifelse(xlimmax>=100, 50, 100)))
        
        par(mgp=c(1,1,0))
        hist(rep.dec$weight[rep.dec$parasitic=="Y"], breaks=temp$breaks, col=input$par.color,     border=input$par.color,     xlim=c(0, xlimmax), ylim=c(0,ylimmax),         axes=F, prob=F, main="Adult Weight", xlab="" , ylab="Counts", cex.lab=1.6, cex.main=1.7, cex.axis=1.7)
        hist(rep.dec$weight[rep.dec$parasitic=="N"], breaks=temp$breaks, col=input$non.par.color, border=input$non.par.color, xlim=c(0, xlimmax), ylim=c(0,ylimmax), add=T , axes=F, prob=F, cex.lab=1.6)
        
        axis(1, pos=0, labels=T,  at=seq(0, xlimmax, xlabel), padj=0.5, cex.axis=1.5)
        axis(2, pos=0, las=1, labels=T, at=seq(0,ylimmax,ylimseq), padj=0.5, cex.axis=1.5)
        axis(3, pos=ylimmax, labels=F, lwd.ticks=0)
        axis(4, pos=xlimmax, labels=F, lwd.ticks=0)
        mtext(side=1, line=3, "Weight (g)",cex=1.7)
        
        segments ( x0=0, y0=0, x1=0, y1=ylimmax ) #avoid haning bars
        
        
        output$plot2 <- renderPlot({ #start of second plot information
          xlimmax2 <- ifelse(max(rep.dec$eggs)<1000, 1000, ifelse(max(rep.dec$eggs)<10000, 10000, ifelse(max(rep.dec$eggs)<100000, 100000, 400000)))
          ifelse( xlimmax2 <= 1000, temp2<- hist(rep.dec$eggs, breaks=seq(0,xlimmax2, 10), plot=F), temp2<- hist(rep.dec$eggs, breaks=seq(0,xlimmax2, 100), plot=F))
          ylimmax2 <- max(round(max(ceiling(temp2$counts)),  -1), round(max(ceiling(temp2$counts))+5,  -1))
          
          par(mgp=c(1,1,0))
          hist(rep.dec$eggs[rep.dec$parasitic=="Y"], breaks=temp2$breaks, col=input$par.color,     border=input$par.color,     xlim=c(0, xlimmax2), ylim=c(0,ylimmax2),         axes=F, prob=F, main="Adult Fecundity", xlab="" , ylab="Counts", cex.lab=1.6, cex.main=1.7, cex.axis=1.7)
          hist(rep.dec$eggs[rep.dec$parasitic=="N"], breaks=temp2$breaks, col=input$non.par.color, border=input$non.par.color, xlim=c(0, xlimmax2), ylim=c(0,ylimmax2), add=T , axes=F, prob=F, cex.lab=1.6)
          
          label <- ifelse(xlimmax2<=1000, 200, ifelse(xlimmax2<=10000, 1000, ifelse(xlimmax2<=100000, 10000, 100000)))
          
          
          axis(1, pos=0, labels=T,  at=seq(0, xlimmax2, label), padj=0.5, cex.axis=1.5)
          axis(2, pos=0, las=1, labels=T, at=seq(0,ylimmax2, ylimseq), padj=0.5, cex.axis=1.5)
          axis(3, pos=ylimmax2, labels=F, lwd.ticks=0)
          axis(4, pos=xlimmax2, labels=F, lwd.ticks=0)
          mtext(side=1, line=3, "Absolute Fecundity (eggs)", cex=1.7)
          
          segments ( x0=0, y0=0, x1=0, y1=ylimmax ) #avoid haning bars
        }) #end of second plot information
        
        
        
        output$summary <- renderTable({
          
          STORE <- plyr::count(rep.dec[,c(1:16,19:21)]) #collect these data to present
          STORE <- STORE[order(STORE$strategy),]        #sort the data to get started
          #the following will be a bit tedious but it makes it easier to bug check, for each stat we are going to calculate it, sort it by strategy and then attach it
          wght.mn <- round (aggregate( rep.dec$weight, list(rep.dec$strategy), mean), 2)  #mean for adult weights
          wght.mn <- wght.mn[order(wght.mn[,1]),]
          
          wght.sd <- round (aggregate( rep.dec$weight, list(rep.dec$strategy), sd), 2)  #sd
          wght.sd <- wght.sd[order(wght.sd[,1]),]
          
          egg.mn <- aggregate( rep.dec$eggs, list(rep.dec$strategy), mean) #mean for eggs
          egg.mn <- egg.mn[order(egg.mn[,1]),]
          
          egg.sd <- aggregate( rep.dec$eggs, list(rep.dec$strategy), sd) #sd
          egg.sd <- egg.sd[order(egg.sd[,1]),]
          
          STORE <- cbind (STORE, wght.mn[,2], wght.sd[,2], as.integer(egg.mn[[2]],0), as.integer(egg.sd[[2]],0) )
          STORE <- STORE[order(STORE$freq, decreasing=T),]
          STORE <- STORE[,c(1:16,18:24)]
          colnames(STORE) <- c("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "Max Age", "Parasitic?", "N", "Avg Weight", "SD Weight", "Avg Fecundity", "SD Fecundity")
          STORE
          
        })
        
      }) #Brackets closing "renderPlot" expression I
  })#isolate
} #Brackets closing "shinyServer" function
